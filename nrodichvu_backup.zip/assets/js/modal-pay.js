                // var modalClose =  document.querySelector('.btn-close');
				// var modalPay =   document.querySelector('.modal__pay');
				// var modalPayoverlay =  document.querySelector('.modal__pay-overlay');
				// var modalBuyNow =  document.querySelector('.content_price-btn');
				// //  modalClose.addEventListener('click', function(){
				// //     modalPay.classList.add('activetwo');
				// // });

				// // modalPayoverlay.addEventListener('click', function(){
				// //     modalPay.classList.add('activetwo');
				// // });
				// modalBuyNow.addEventListener('click', function(){
				// 	modalPay.classList.add('activefirst');
				// });