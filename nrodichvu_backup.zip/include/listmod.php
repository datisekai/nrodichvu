 
                    <div class="col l-10 m-12 c-12">
                        <div class="home-product">
                            <div class="row margin-top-on-tablet">
                                <div class="tk__done">
                                    <h1>MOD FREE</h1>
                                   
                                    <table class="tk__done-table">
                                        <tr>
                                            <th>ID</th>
                                            <th>THỜI GIAN</th>
                                            <th>LOẠI</th>
                                            <th>LINK TẢI</th>
                                           
                                            <th>TRẠNG THÁI</th>
                                            <th>NGUỒN:</th>
                                        </tr>

                                        <tr  class="space">
                                            <td>#1</td>
                                            <td>22/9/2021</td>
                                            <td>AUTO MMD</td>
                                            <td>https://www.mediafire.com/file/modmuamdxxx/Mod.rar/file</td>
                                           
                                            <td>OKE</td>
                                            <td>Datisekai</td>
                                        </tr>

                                        <tr class="space">
                                        <td>#2</td>
                                            <td>22/9/2021</td>
                                            <td>UP DETU</td>
                                            <td>https://www.mediafire.com/file/m6t0kpo0fedz94z/Up_De_Tu.rar/file</td>
                                           
                                            <td>OKE</td>
                                            <td>Shopwibu.com</td>
                                        </tr>
                                    </table>
                                </div>
                             
                        </div>
                    </div>

                    </div>
                </div>
            </div>
          