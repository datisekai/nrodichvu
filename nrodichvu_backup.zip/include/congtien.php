 
                    <div class="col l-10 m-12 c-12">
                        <div class="home-product">
                            <div class="row margin-top-on-tablet">
                            
                               <div class="information">
                                   <form action="" method="post">

                                       <h1>QUẢN LÝ VÍ KHÁCH HÀNG</h1>
                                       <div class="user">

                                           <p class="title__change">Tên tài khoản:</p>
                                          <input type="text" name="user" placeholder="Nhập vào tài khoản..." class="input-change">
                                       </div>

                                       
                                          <div class="passnew">

                                              <p class="title__change">Số tiền muốn cộng, trừ:</p>
                                              <input type="text" name="sotiengd" placeholder="Số tiền muốn cộng, trừ ...." class="input-change">
                                          </div>
                                        
                

                                           <div class="submit-change-congtien">
                                               <input type="submit" name="cong" value="Cộng tiền" class="submit-change-btn">
                                               <input type="submit" name="tru" value="Trừ tiền" class="submit-change-btn-tru">
                                           </div>
                                   </form>
                               </div>
                                
                             
                        </div>
                    </div>

                    </div>
                </div>
            </div>
