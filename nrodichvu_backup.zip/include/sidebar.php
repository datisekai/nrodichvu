<div class="grid wide">

    <div class="col l-2 m-2 c-2">
                            <nav class="category">
                                <h3 class="category__heading">
                                    <i class="category__heading-icon ti-menu-alt"></i>
                                    Danh Mục
                                </h3>
                                <ul class="category-list">
    
                                    <li class="category-item">
                                        <a href="" class="category-item__link" value="">SƠ SINH</a>
                                    </li>
                                    <li class="category-item">
                                        <a href="" class="category-item__link" value="">TẦM TRUNG</a>
                                    </li>
                                    <li class="category-item">
                                        <a href="" class="category-item__link" value="">SHOP ĐỒ</a>
                                    </li>
                                
                            
                                    
                                </ul>
                            </nav>
                        </div>

