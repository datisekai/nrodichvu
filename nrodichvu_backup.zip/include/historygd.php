<div class="grid wide">
    <div class="row">
        <div class="col l-2 m-0 c-0">
                                <nav class="category">
                                    <h3 class="category__heading">
                                        <i class="category__heading-icon ti-menu-alt"></i>
                                        LỊCH SỬ
                                    </h3>
                                    <ul class="category-list">
        
                                       
                                        <li class="category-item">
                                            <a href="lsgd.php?id=1" class="category-item__link" value="">TẦM TRUNG</a>
                                        </li>
                                        <li class="category-item">
                                            <a href="lsgd.php?id=2" class="category-item__link" value="">SƠ SINH</a>
                                        </li>
                                        <li class="category-item">
                                            <a href="lsgd.php?id=3" class="category-item__link" value="">VẬT PHẨM</a>
                                        </li>
                                        
                                    
                                        
                                    </ul>
                                </nav>
                            </div>

