<div class="grid wide">
  
        <div class="row">
        <div class="col l-2 m-0 c-0">
                                <nav class="category">
                                    <h3 class="category__heading">
                                        <i class="category__heading-icon ti-menu-alt"></i>
                                        CHỨC NĂNG
                                    </h3>
                                    <ul class="category-list">
        
                                       
                                        <li class="category-item">
                                            <a href="naptien.php?id=1" class="category-item__link" value="">NẠP MOMO</a>
                                        </li>
                                        <li class="category-item">
                                            <a href="naptien.php?id=2" class="category-item__link" value="">NẠP TSR</a>
                                        </li>
                                        <li class="category-item">
                                            <a href="naptien.php?id=3" class="category-item__link" value="">NẠP AZCARD</a>
                                        </li>
                                        <li class="category-item">
                                            <a href="naptien.php?id=4" class="category-item__link" value="">NẠP ATM</a>
                                        </li>
                                    
                                        
                                    </ul>
                                </nav>
                            </div>

