 
                    <div class="col l-10 m-12 c-12">
                        <div class="home-product">
                            <div class="row margin-top-on-tablet">
                            
                               <div class="information">
                                   <form action="" method="post">

                                       <h1>ĐỔI MẬT KHẨU</h1>
                                       <div class="user">

                                           <p class="title__change">Tên tài khoản:</p>
                                          <input type="text" name="user" value="<?php echo $_SESSION['login']; ?>" class="input-change">
                                       </div>

                                       <div class="passold">

                                           <p class="title__change">Mật khẩu cũ:</p>
                                          
                                          <input type="text" name="passold" placeholder="Nhập mật khẩu cũ ...." class="input-change">
                                       </div>
                                          <div class="passnew">

                                              <p class="title__change">Mật khẩu mới:</p>
                                              <input type="text" name="passnew" placeholder="Nhập mật khẩu mới ...." class="input-change">
                                          </div>
                                        
                                          <div class="rppassnew">

                                              <p class="title__change">Nhập lại mật khẩu mới:</p>
                                              <input type="text" name="rppassnew" placeholder="Nhập lại mật khẩu mới ...." class="input-change">
                                          </div>

                                           <div class="submit-change">
                                               <input type="submit" name="submit" value="Đổi mật khẩu" class="submit-change-btn">
                                           </div>
                                   </form>
                               </div>
                                
                             
                        </div>
                    </div>

                    </div>
                </div>
            </div>
